<?php

namespace Modules\Ipanel\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Ipanel\Entities\PengetahuanCategoryModel;
use Modules\Ipanel\Entities\PengetahuanModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Validator;
use App\Helper\ImageManager;

class PengetahuanController extends Controller
{
    use ImageManager;
    public $table_pengetahuan           ="pengetahuan";
    public $table_pengetahuan_content   ="pengetahuan_content";
    public $table_pengetahuan_category  ="pengetahuan_category";

    public $assets_pengetahuan          ="public/images/assets_pengetahuan/";
    public $paging                      =5;
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        if(isset($_GET['search'])){
            $query      = DB::table($this->table_pengetahuan)->where('pgTitle',"like","%".$_GET['search']."%")->paginate($this->paging);
        }else{
            $query      = DB::table($this->table_pengetahuan)->paginate($this->paging);
        }
        $data['data']           =$query;
        $data['assets_storage'] ="storage/".$this->assets_pengetahuan;
        
        return view('ipanel::pengetahuan.index',['data_pengetahuan'=>$data]);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $data=array(
            "summernote"=>array(
                array(
                    "class"=>".summernote",
                    "height"=>200
                )
            ),
            "kategori"  =>DB::table($this->table_pengetahuan_category)->get(),
            "select2combo" => "select2combo",
            "datetime_picker" => "datetime_picker",
            "form_ajax_upload"=>array(
                "theid"=>"#pengetahuan",
                "thebutton"=>".btn-submit"
            ),
            "file_upload_theme_two" => "file_upload_theme_two",
            "new_ajax"=>"
                $('.content_content').hide();
                $('.content_pdf').hide();
                $('.content_video').hide();

                $('.type_content').change(function() {
                    if($('.type_content').val()=='text'){
                        $('.content_content').show();
                        $('.content_pdf').hide();
                        $('.content_video').hide();
                    }
                    if($('.type_content').val()=='document'){
                        $('.content_content').hide();
                        $('.content_pdf').show();
                        $('.content_video').hide();
                    }
                    if($('.type_content').val()=='video'){
                        $('.content_content').hide();
                        $('.content_pdf').hide();
                        $('.content_video').show();
                    }
                });
            ",
        );
        return view('ipanel::pengetahuan.create',['data'=>$data]);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
        
        // print "<pre>";
        // print_r($_POST);
        // print_r($_FILES);
        // exit;

        // print $totime=strtotime($_POST['pemdatetime']);
        // print "<br>";
        // print date("Y-m-d H:i:s",$totime);
        // print "<br>";
        // print $_POST['pemdatetime']."<br>";
        // exit;
        #VALIDATION -------------------------------------------------------------------------------------------
        $payload_vadidator=[
            'pemcat'=>'required',
            'pemtype'=>'required',
            'pemtitle'=>'required',
            'pemdatetime'=>'required',
            'pemtimeestimate'=>'required|numeric',
            'pemdesc'=>'required',
            'pemfile' => 'image|mimes:jpeg,png,jpg|max:2048',
            "content_type"=>'required',
        ];
        if($request->content_type=="document"){
            $payload_vadidator['content_pdf']='required|mimes:pdf|max:10000';
        }
        if($request->content_type=="video"){
            $payload_vadidator['content_video']='required|mimes:mp4,mov,ogg,qt | max:20000';
        }
        if($request->content_type=="text"){
            $payload_vadidator['content_content']='required';
        }
        $payload_error=[
            'pemtitle.required' => 'Kolom Nama Kategori Wajib Di isi.',
            'pemdesc.required' => 'Kolom Keterangan Wajib Di isi.',

            "content_type.required" => 'Kolom Tipe Konten [Pada TAB Pengetahuan Konten] Wajib Di isi.',
            "content_content.required" => 'Kolom Isi <strong>Konten</strong> [Pada <strong>TAB Pengetahuan Konten</strong>] Wajib Di isi.',
            "content_video.required" => 'Kolom Isi <strong>Video File</strong> [Pada <strong>TAB Pengetahuan Konten</strong>] Wajib Di isi.',
            "content_pdf.required" => 'Kolom Isi <strong>PDF File</strong> [Pada <strong>TAB Pengetahuan Konten</strong>] Wajib Di isi.',
        ];
        $validator = \Validator::make($request->all(),$payload_vadidator,$payload_error);
        #END VALIDATION -----------------------------------------------------------------------------------------

        if ($validator->fails()){
            return response()->json(['errors'=>$validator->errors()->all()]);
            exit;
        }else{
            $data['image']="";;
            $path       = storage_path($this->assets_pengetahuan);
            $path_new   =$this->assets_pengetahuan;
            $folder_    ="";
            
            !is_dir($path_new) &&
                mkdir($path_new, 0777, true);
            
            if($request->file('pemfile') or $request->file('content_pdf') or $request->file('content_video')) {
                if(!is_dir($path_new.date("Y"))){
                    mkdir($path_new.date("Y"));
                }
                if(!is_dir($path_new.date("Y")."/".date("m"))){
                    mkdir($path_new.date("Y")."/".date("m"));
                }
                if(!is_dir($path_new.date("Y")."/".date("m")."/".date("Ymd"))){
                    mkdir($path_new.date("Y")."/".date("m")."/".date("Ymd"));
                }
                $folder_    =date("Y")."/".date("m")."/".date("Ymd")."/";
            }

            if($file = $request->file('pemfile')) {
                if($request->file('pemfile')){
                    $file= $request->file('pemfile');
                    $fileNames=uniqid().'.'.$file->getClientOriginalExtension();
                    $file->storeAs($path_new.$folder_,$fileNames);
                    $data['image']=$fileNames;
                }
            }
           
            $pg_id    =$this->nextid();
            $pg_title = $pg_id."-".\Str::slug($request->pemtitle);
           #pgId 	id_user 	catId 	pgType 	pgTitle 	pgPermalink 	pgTimePost 	pgImage 	pgDescription 	pgEstimation 	pgViewed 	pgDisplay 	pgReported 	created_at 	updated_at 	
            $payload=[
                'pgId'           => $pg_id,
                'id_user'        => '1',
                'catId'          => $request->pemcat,
                'pgType'         => $request->pemtype,
                'pgTitle'        => $request->pemtitle,
                'pgPermalink'    => $pg_title,
                'pgTimePost'     => date("Y-m-d H:i:s",strtotime($request->pemdatetime)),
                'pgDescription'  => $request->pemdesc,
                'pgEstimation'   => $request->pemtimeestimate,
                'pgDisplay'      =>'y',
                'pgViewed'       =>0,
            ];
            if($file = $request->file('pemfile')) {
                $payload['pgImage'] = $folder_.$data['image'];
            }

            $save_pengetahuan=DB::table($this->table_pengetahuan)->insert($payload);
            if($save_pengetahuan){
                # 	pcId 	pgId 	pcContentType 	pcText 	pcVideo 	pcDocuments 	pcDuration 	pcSort 	created_at 	updated_at 	
                #if($file = $request->file('content')) {
                $payload_c=[
                    'pcId'          =>$this->nextid_content(),
                    'pgId'          =>$pg_id,
                    'pcContentType' =>$request->content_type,
                    'pcDuration'    =>$request->content_estimate,
                    'pcSort'        =>$this->next_sort($pg_id),
                ];
                if($request->content_type=="document"){
                    if($file = $request->file('content_pdf')) {
                        $file= $request->file('content_pdf');
                        $fileNames=uniqid().'.'.$file->getClientOriginalExtension();
                        $file->storeAs($path_new.$folder_,$fileNames);
                        $data['content_pdf']=$folder_.$fileNames;

                        $payload_c['pcDocuments']   =$data['content_pdf'];
                    }
                }

                if($request->content_type=="video"){
                    if($file = $request->file('content_video')) {
                        $file= $request->file('content_video');
                        $fileNames=uniqid().'.'.$file->getClientOriginalExtension();
                        $file->storeAs($path_new.$folder_,$fileNames);
                        $data['content_video']=$folder_.$fileNames;
    
                        $payload_c['pcVideo']   =$data['content_video'];
                    }
                }

                if($request->content_type=="text"){
                    $payload_c['pcText']   =$request->content_content;
                }

                $save_content=DB::table($this->table_pengetahuan_content)->insert($payload_c);
            }
            /*
            [pemcat] => 1
            [pemtype] => 
            [pemdatetime] => 
            [pemtitle] => 
            [pemtimeestimate] => 
            [pemdesc] =>
            */

            return response()->json(['success'=>route('pengetahuan.index')]);
            exit;
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $data_get = DB::table($this->table_pengetahuan)
                            ->leftJoin($this->table_pengetahuan_content, $this->table_pengetahuan.'.pgId', '=', $this->table_pengetahuan_content.'.pgId')
                            ->leftJoin($this->table_pengetahuan_category, $this->table_pengetahuan_category.'.catId', '=', $this->table_pengetahuan.'.catId')
                            ->where('pgPermalink', $id)
                            ->first();
        $data=array(
            "datetime_picker" => "datetime_picker",
            "new_ajax"=>"",
            "data"  =>$data_get,
        );
        
        return view('ipanel::pengetahuan.show',['data'=>$data]);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($getid)
    {
        $data_get = DB::table($this->table_pengetahuan)
                            ->leftJoin($this->table_pengetahuan_content, $this->table_pengetahuan.'.pgId', '=', $this->table_pengetahuan_content.'.pgId')
                            ->where('pgPermalink', $getid)
                            ->first();
        $data=array(
            "data"=>$data_get,
            "summernote"=>array(
                array(
                    "class"=>".summernote",
                    "height"=>200
                )
            ),
            "kategori"  =>DB::table($this->table_pengetahuan_category)->get(),
            "form_ajax_upload"=>array(
                "theid"=>"#pengetahuan",
                "thebutton"=>".btn-submit"
            ),
            "datetime_picker" => "datetime_picker",
            "file_upload_theme_two" => "file_upload_theme_two",
            "new_ajax"=>"
                $('.type_content').change(function() {
                    if($('.type_content').val()=='text'){
                        $('.content_content').show();
                        $('.content_pdf').hide();
                        $('.content_video').hide();
                    }
                    if($('.type_content').val()=='document'){
                        $('.content_content').hide();
                        $('.content_pdf').show();
                        $('.content_video').hide();
                    }
                    if($('.type_content').val()=='video'){
                        $('.content_content').hide();
                        $('.content_pdf').hide();
                        $('.content_video').show();
                    }
                });
            ",
        );
        if($data_get->pcContentType=="document"){
            $data['new_ajax'].="$('.content_content').hide();$('.content_pdf').show();$('.content_video').hide();";
        }
        if($data_get->pcContentType=="text"){
            $data['new_ajax'].="$('.content_content').show();$('.content_pdf').hide();$('.content_video').hide();";
        }
        if($data_get->pcContentType=="video"){
            $data['new_ajax'].="$('.content_content').hide();$('.content_pdf').hide();$('.content_video').show();";
        }
        
        return view('ipanel::pengetahuan.edit',['data'=>$data]);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $validator = \Validator::make($request->all(), [
            'pemcat'=>'required',
            'pemtype'=>'required',
            'pemtitle'=>'required',
            'pemdatetime'=>'required',
            'pemtimeestimate'=>'required|numeric',
            'pemdesc'=>'required',
            'pemfile' => 'image|mimes:jpeg,png,jpg|max:2048',
        ], [
            'pemtitle.required' => 'Kolom Nama Kategori Wajib Di isi.',
            'pemdesc.required' => 'Kolom Keterangan Wajib Di isi.',
        ]);

        if ($validator->fails()){
            return response()->json(['errors'=>$validator->errors()->all()]);
            exit;
        }else{
            $data['image']="";;
            $path       = storage_path($this->assets_pengetahuan);
            $path_new   =$this->assets_pengetahuan;
            $data_get   = DB::table($this->table_pengetahuan)
                                ->leftJoin($this->table_pengetahuan_content, $this->table_pengetahuan.'.pgId', '=', $this->table_pengetahuan_content.'.pgId')
                                ->where('pgPermalink', $id)
                                ->first();
            $folder_    ="";
            !is_dir($path_new) &&
                mkdir($path_new, 0777, true);
            
            if($request->file('pemfile') or $request->file('content_pdf') or $request->file('content_video')) {
                if(!is_dir($path_new.date("Y"))){
                    mkdir($path_new.date("Y"));
                }
                if(!is_dir($path_new.date("Y")."/".date("m"))){
                    mkdir($path_new.date("Y")."/".date("m"));
                }
                if(!is_dir($path_new.date("Y")."/".date("m")."/".date("Ymd"))){
                    mkdir($path_new.date("Y")."/".date("m")."/".date("Ymd"));
                }
                $folder_    =date("Y")."/".date("m")."/".date("Ymd")."/";
            }    
            if($file = $request->file('pemfile')) {               
                if($request->file('pemfile')){
                    $file= $request->file('pemfile');
                    $fileNames=uniqid().'.'.$file->getClientOriginalExtension();
                    $file->storeAs($path_new.$folder_,$fileNames);
                    $data['image']=$fileNames;

                    $delete_file=$this->removeImage($this->assets_pengetahuan,$data_get->pgImage);
                }
            }
           
            $pg_id    =$this->nextid();
            $pg_title = $data_get->pgId."-".\Str::slug($request->pemtitle);
            list($tgl,$jam)      =explode(" ",$request->pemdatetime);
            list($tg,$bl,$th)    =explode("/",$tgl);
            $payload=[
                'id_user'        => '1',
                'catId'          => $request->pemcat,
                'pgType'         => $request->pemtype,
                'pgTitle'        => $request->pemtitle,
                'pgPermalink'    => $pg_title,
                'pgTimePost'     => $th."-".$bl."-".$tg." ".$jam,
                'pgDescription'  => $request->pemdesc,
                'pgEstimation'   => $request->pemtimeestimate,
            ];

            // $dataxsd=strtotime($request->pemdatetime);
            // print "<pre>";
            // print "POST: ".$request->pemdatetime."<br>";
            // print "TIMES: ".$dataxsd."<br>";
            // print "TO DATE: ".date('d mM Y H:i:s',$dataxsd)."<br>";
            // print_r($payload);

            // exit;

            if($file = $request->file('pemfile')) {
                $payload['pgImage']=$folder_.$data['image'];
            }

            
            #DB::enableQueryLog();
            $update_pengetahuan=DB::table($this->table_pengetahuan)->where('pgPermalink', $id)->update($payload);
            #$query = DB::getQueryLog();
            #dd($update_pengetahuan);exit;
            #if($update_pengetahuan){
                $payload_c=[
                    'pcContentType' =>$request->content_type,
                    'pcDuration'    =>$request->content_estimate,
                ];
                if($request->content_type=="document"){
                    if($file = $request->file('content_pdf')) {
                        $file= $request->file('content_pdf');
                        $fileNames=uniqid().'.'.$file->getClientOriginalExtension();
                        $file->storeAs($path_new.$folder_,$fileNames);
                        $data['content_pdf']=$folder_.$fileNames;

                        $payload_c['pcDocuments']   =$data['content_pdf'];
                        $payload_c['pcVideo']       ="";
                        $payload_c['pcText']        ="";
                    }
                }

                if($request->content_type=="video"){
                    if($file = $request->file('content_video')) {
                        $file= $request->file('content_video');
                        $fileNames=uniqid().'.'.$file->getClientOriginalExtension();
                        $file->storeAs($path_new.$folder_,$fileNames);
                        $data['content_video']=$folder_.$fileNames;
    
                        $payload_c['pcVideo']       =$data['content_video'];
                        $payload_c['pcDocuments']   ="";
                        $payload_c['pcText']        ="";
                    }
                }

                if($request->content_type=="text"){
                    $payload_c['pcText']        =$request->content_content;
                    $payload_c['pcDocuments']   ="";
                    $payload_c['pcVideo']       ="";
                }

                // print "<pre>";
                // print_r($payload_c);
                // exit;

                $save_content=DB::table($this->table_pengetahuan_content)->where('pcId', $data_get->pcId)->update($payload_c);
                if($save_content){
                    if($data_get->pcContentType=="document"){
                        $delete_file=$this->removeImage($this->assets_pengetahuan,$data_get->pcDocuments);
                    }
                    if($data_get->pcContentType=="video"){
                        $delete_file=$this->removeImage($this->assets_pengetahuan,$data_get->pcVideo);
                    }
                }
            #}else{
            #    return response()->json(['errors'=>"Gagal melakukan Update Data !!"]);
            #    exit;
            #}
            
            return response()->json(['success'=>route('pengetahuan.index')]);
            exit;
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        $data_get = DB::table($this->table_pengetahuan)
                            ->leftJoin($this->table_pengetahuan_content, $this->table_pengetahuan.'.pgId', '=', $this->table_pengetahuan_content.'.pgId')
                            ->where('pgPermalink', $id)
                            ->first();
        if(($data_get->catId)>0){
            $run_query=DB::table($this->table_pengetahuan)->where('pgPermalink', $id)->delete();
            if($run_query){
                $this->removeImage($this->assets_pengetahuan,$data_get->pgImage);
                if($data_get->pcContentType=="document"){
                    $this->removeImage($this->assets_pengetahuan,$data_get->pcDocuments);
                }
                if($data_get->pcContentType=="video"){
                    $this->removeImage($this->assets_pengetahuan,$data_get->pcVideo);
                }
                
            }
            return response()->json(['success'=>route('pengetahuan.index')]);
            exit;
        }else{

        }
    }

    public function nextid(){
        $order =DB::table($this->table_pengetahuan)->max('pgId');
		return ($order + 1);
    }

    public function nextid_content(){
        $order =DB::table($this->table_pengetahuan_content)->max('pcId');
		return ($order + 1);
    }

    public function next_sort($pgid){
        $order =DB::table($this->table_pengetahuan_content)
                        ->where('pgId', $pgid)
                        ->max('pcSort');
		return ($order + 1);
    }

    public function removeImage($folder_,$file_){  
        if(\Storage::exists($folder_.$file_)){
            \Storage::delete($folder_.$file_);
        }else{
            return "Gagal Hapus File";
        }
    }
}
