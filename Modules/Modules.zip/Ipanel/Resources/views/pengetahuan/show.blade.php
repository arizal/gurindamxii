@extends('ipanel::layouts.master')

@section('content')
<?php /* <h3>{{$categori_pembelajaran->catPermalink}}</h3>
<p>Writen By : {{$categori_pembelajaran->catPermalink}}</p>
<p>Number of Page : {{$categori_pembelajaran->catPermalink}}</p>
<p>Publisher On : {{$categori_pembelajaran->catPermalink}}</p>
*/ ?>
<pre style="height:200px;">
<?php print_r($data) ?>

</pre>


<div class="widget-box">
    <div class="widget-header">
        <h4 class="smaller">
            Pengetahuan »
            <small>{{$data['data']->pgTitle}}</small>
        </h4>
    </div>

    <div class="widget-body">
        <div class="widget-main">
            <div class="profile-user-info profile-user-info-striped" style="margin-bottom:20px;">
                <div class="profile-info-row">
                    <div class="profile-info-name"> Kategori Pengetahuan: </div>
                    <div class="profile-info-value"><span>{{$data['data']->catName}}</span></div>
                </div>
                <div class="profile-info-row">
                    <div class="profile-info-name"> Judul Pengetahuan: </div>
                    <div class="profile-info-value"><span>{{$data['data']->pgTitle}}</span></div>
                </div>
                <div class="profile-info-row">
                    <div class="profile-info-name"> Keterangan: </div>
                    <div class="profile-info-value"><span>{!!$data['data']->pgDescription!!}</span></div>
                </div>
                <div class="profile-info-row">
                    <div class="profile-info-name"> Estimasi Waktu: </div>
                    <div class="profile-info-value"><span>{{$data['data']->pgEstimation}} Menit</span></div>
                </div>
                <hr>
            </div>
            <h3 class="header smaller lighter green">
                <i class="ace-icon fa fa-list"></i>
                Konten
            </h3>
            <div class="profile-user-info profile-user-info-striped" style="margin-bottom:20px;">
                <div class="profile-info-row">
                    <div class="profile-info-name"> Tipe Konten: </div>
                    <div class="profile-info-value"><span>{{ucfirst($data['data']->pcContentType)}}</span></div>
                </div>
                <div class="profile-info-row">
                    <div class="profile-info-name"> Waktu: </div>
                    <div class="profile-info-value"><span>{{$data['data']->pgEstimation}}</span></div>
                </div>
                <div class="profile-info-row">
                    <div class="profile-info-name" style="vertical-align:top"> Isi {{ucfirst($data['data']->pcContentType)}}: </div>
                    <div class="profile-info-value"><span>
                        @if($data['data']->pcContentType =='document')
                            <object data="{{asset('storage/images/assets_pengetahuan/'.$data['data']->pcDocuments)}}" type="application/pdf" width="100%" height="400">
                                <a href="{{asset('storage/images/assets_pengetahuan/'.$data['data']->pcDocuments)}}">{{$data['data']->pcContentType}}</a>
                            </object>
                        @endif
                        @if($data['data']->pcContentType =='video')
                            <video width="100%" style="aspect-ratio: 16 / 9" controls>
                                <source src="{{asset('storage/images/assets_pengetahuan/'.$data['data']->pcVideo)}}" type="video/mp4">
                                <source src="movie.ogg" type="video/ogg">
                                    Your browser does not support the video tag.
                            </video>
                        @endif
                        @if($data['data']->pcContentType =='text')
                            {!!$data['data']->pcText!!}
                        @endif
                    </span></div>
                </div>
            </div>
        </div>
    </div>
</div>
<a href="{{route('pengetahuan.index')}}" class="btn btn-secondary">Back to Index</a>
@endsection