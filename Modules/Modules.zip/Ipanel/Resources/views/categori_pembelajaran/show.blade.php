@extends('ipanel::layouts.master')

@section('content')
<?php /* <h3>{{$categori_pembelajaran->catPermalink}}</h3>
<p>Writen By : {{$categori_pembelajaran->catPermalink}}</p>
<p>Number of Page : {{$categori_pembelajaran->catPermalink}}</p>
<p>Publisher On : {{$categori_pembelajaran->catPermalink}}</p>
*/ ?>
<a href="<?php /*{{route('categori_pembelajaran.index')}} */ ?>" class="btn btn-secondary">Back to Index</a>
@endsection