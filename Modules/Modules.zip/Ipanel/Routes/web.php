<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('ipanel')->group(function() {
    Route::get('/', 'IpanelController@index');
});

// Route::group(['prefix'=>'ipanel'],function(){
//     Route::get('/','IpanelController@index');
// });
use App\Http\Controllers\BooksController;
Route::prefix("ipanel")->namespace('\Modules\Ipanel\Http\Controllers')->middleware(['auth'])->group(function(){
    Route::resource('categoripembelajaran','CategoriPembelajaranController');
    Route::resource('mpembelajaran','PembelajaranController');

    
    #Route::resource('tambahdata', BooksController::class);
    #Route::get('mpembelajaran/tambahdata/{id}', 'PembelajaranController@tambahdata')->name('mpembelajaran.tambahdata');
    Route::get('mpembelajaran/create_submateri/{id}', 'PembelajaranController@create_submateri')->name('mpembelajaran.create_submateri');
    Route::post('mpembelajaran/store_submateri/{id}', 'PembelajaranController@store_submateri')->name('mpembelajaran.store_submateri');
    Route::get('mpembelajaran/edit_submateri/{id}', 'PembelajaranController@edit_submateri')->name('mpembelajaran.edit_submateri');
    Route::get('mpembelajaran/destroy_submateri/{id}', 'PembelajaranController@destroy_submateri')->name('mpembelajaran.destroy_submateri');
    Route::post('mpembelajaran/update_submateri/{id}', 'PembelajaranController@update_submateri')->name('mpembelajaran.update_submateri');
    
    #NEW_MENU_NYA_YAA########################################################################################
    Route::resource('pengetahuan','PengetahuanController');
    Route::resource('pengetahuan_category','PengetahuanCategoryController');
    Route::resource('pengetahuan_highlight','PengetahuanHighlightController');
    Route::resource('pengetahuan_rating','PengetahuanRatingController');
    Route::resource('pengetahuan_comments','PengetahuanCommentController');

    Route::resource('contact_us','ContactUsController');
    
    
    #Route::resource('create_submateri','PembelajaranController');  
    #Route::get('create_submateri', 'PembelajaranController@open'); 
    
    #Route::get('Purchase_details/open', 'Purchase_detailsController@open');
    #Route::resource('Purchase_details', 'Purchase_detailsController');
});