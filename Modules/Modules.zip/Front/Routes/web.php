<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('front')->group(function() {
    Route::get('/', 'FrontController@index');

    Route::resource('materi','MateriController');
    Route::post('materi/post_comments/{id}', 'MateriController@post_comments')->name('materi.post_comments');
    Route::post('materi/post_replycomments/{id}', 'MateriController@post_replycomments')->name('materi.post_replycomments');

    Route::resource('dashboard','DashboardController');
    Route::resource('setting','SettingController');
    Route::resource('contactus','ContactusController');
    Route::resource('riwayat_baca','RiwayatBacaController');

    Route::resource('daftarku','DaftarkuController');
    Route::get('daftarku/disukai/{id}', 'DaftarkuController@disukai')->name('daftarku.disukai');
    Route::get('daftarku/ditandai/{id}', 'DaftarkuController@ditandai')->name('daftarku.ditandai');
    Route::get('daftarku/daftar_baca/{id}', 'DaftarkuController@daftar_baca')->name('daftarku.daftar_baca');

    Route::resource('post_ajax','PostAjaxController');

    #Route::post('front/post_contactus', 'FrontController@post_contactus')->name('front.post_contactus');

});
